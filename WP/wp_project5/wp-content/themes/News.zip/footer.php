 <footer id="footer">
            <div class="footer_top">
                <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-4">
                        <div class="footer_widget wow fadeInLeftBig">
                            <h2>About</h2>
                            The Telegraph is a major Bangladeshi English-language daily newspaper based Worldwide , It
                            also operates an online Bengali version known as the Bangla Telegraph.
                            Telegraph is here to be the platform for that new voice, and new vision. Our pledge to those
                            we serve is to seek the truth, deliver the facts and offer. <br>
                            It also operates an online Bengali version known as the Bangla Telegraph.
                            Telegraph is here to be the platform for that new voice, and new vision. <br>
                            It also operates an online Bengali version known as the Bangla Telegraph.
                            Telegraph is here to be the platform for that new voice, and new vision. Our pledge to those
                            we serve is to seek the truth, deliver the facts and offer.
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-4">
                        <div class="footer_widget wow fadeInDown">
                            <h2>Tag</h2>
                            <ul class="tag_nav">
                                <li><a href="#">Games</a></li>
                                <li><a href="#">Sports</a></li>
                                <li><a href="#">Fashion</a></li>
                                <li><a href="#">Business</a></li>
                                <li><a href="#">Life &amp; Style</a></li>
                                <li><a href="#">Technology</a></li>
                                <li><a href="#">Photo</a></li>
                                <li><a href="#">Slider</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-4">
                        <div class="footer_widget wow fadeInRightBig">
                            <h2>Contact</h2>
                            <p>Office: 48116830-31
                                Advertising: 48116865
                                Fax: News: 48116887
                                info@dhakatelgraph.com, news@dhakatelgraph.com, contact@dhakatelgraph.com</p>
                            <address>
                                Copyright Ⓒ 2012-2022. 2A Media Limited, All Rights Reserved.
                                8/C, FR Tower, Panthapath, Dhaka 1207, Bangladesh.
                                Kazi Anis Ahmed, Publisher
                            </address>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer_bottom">
                <p class="copyright">Copyright &copy; 2022 <a href="../index.html">NewsFeed</a></p>
                <p class="developer">Developed By Sajedul Islam</p>
            </div>
        </footer>
    </div>
    <script src="<?php echo get_template_directory_uri() ?>/assets/js/jquery.min.js"></script>
    <script src="<?php echo get_template_directory_uri() ?>/assets/js/wow.min.js"></script>
    <script src="<?php echo get_template_directory_uri() ?>/assets/js/bootstrap.min.js"></script>
    <script src="<?php echo get_template_directory_uri() ?>/assets/js/slick.min.js"></script>
    <script src="<?php echo get_template_directory_uri() ?>/assets/js/jquery.li-scroller.1.0.js"></script>
    <script src="<?php echo get_template_directory_uri() ?>/assets/js/jquery.newsTicker.min.js"></script>
    <script src="<?php echo get_template_directory_uri() ?>/assets/js/jquery.fancybox.pack.js"></script>
    <script src="<?php echo get_template_directory_uri() ?>/assets/js/custom.js"></script>

    <?php // wp_footer();?>
</body>

</html>
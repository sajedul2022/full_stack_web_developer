<?php

if( ! class_exists( 'Penci_Soledad_Demo_Importer_Helper' ) ):
	class Penci_Soledad_Demo_Importer_Helper {

	}
endif;
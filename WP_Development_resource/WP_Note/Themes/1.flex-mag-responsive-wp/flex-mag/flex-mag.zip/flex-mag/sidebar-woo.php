<div id="sidebar-wrap" class="relative theiaStickySidebar">
	<?php if ( is_active_sidebar( 'sidebar-woo-widget' ) ) { ?>
		<?php dynamic_sidebar( 'sidebar-woo-widget' ); ?>
	<?php } ?>
</div><!--sidebar-wrap-->
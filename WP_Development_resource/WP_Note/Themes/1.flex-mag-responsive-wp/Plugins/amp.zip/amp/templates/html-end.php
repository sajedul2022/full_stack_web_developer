<?php
/**
 * HTML end template part.
 *
 * @package AMP
 */

/**
 * Context.
 *
 * @var AMP_Post_Template $this
 */
?>

<?php do_action( 'amp_post_template_footer', $this ); ?>

</body>
</html>
